package atechnique.models.concrete;

import atechnique.models.interfaces.IStartServerModel;

public class StartServerModel implements IStartServerModel {

}
