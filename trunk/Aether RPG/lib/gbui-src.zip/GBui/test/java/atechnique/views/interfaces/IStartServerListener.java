package atechnique.views.interfaces;

public interface IStartServerListener {
    void cancelPressed();

    void okPressed();
}
