package atechnique;

import atechnique.classfactory.SelectCampaignPresenter;

public class Campaign {
    public void addCampaignChangedListener(SelectCampaignPresenter selectCampaignPresenter) {
    }

    public String getDescription() {
        return null;
    }

    public void setSelectedScenario(CampaignScenario scenario) {
    }
}
