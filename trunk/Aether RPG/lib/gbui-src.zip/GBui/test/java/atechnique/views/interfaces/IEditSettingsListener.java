package atechnique.views.interfaces;

public interface IEditSettingsListener {
    void SaveSettings();

    void CancelPressed();
}
