package atechnique.views.interfaces;

public interface IMainMenuListener {
    void playCampaignPressed();

    void connectToGamePressed();

    void editSettingsPressed();

    void exitPressed();
}
