package atechnique.models.interfaces;

public interface ICampaignChangedListener {
    void stateChanged();
}
