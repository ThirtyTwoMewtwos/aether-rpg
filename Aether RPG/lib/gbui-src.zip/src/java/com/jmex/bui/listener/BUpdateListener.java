/**
 * $ID:$
 * $COPYRIGHT:$
 */
package com.jmex.bui.listener;

import com.jmex.bui.BComponent;

/**
 * @author stigrv
 */
public interface BUpdateListener {
    void update(BComponent component, float time);
}
