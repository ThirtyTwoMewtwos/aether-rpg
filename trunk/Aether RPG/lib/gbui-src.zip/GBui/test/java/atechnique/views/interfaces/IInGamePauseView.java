package atechnique.views.interfaces;

public interface IInGamePauseView extends IGameStateView {
    void addInGamePauseListener(IInGamePauseListener inGamePauseListener);
}
