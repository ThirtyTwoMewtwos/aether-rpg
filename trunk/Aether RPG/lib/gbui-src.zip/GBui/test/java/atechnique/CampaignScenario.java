package atechnique;

public class CampaignScenario {

}
