package com.jme.util;

/**
 * ThrowableHandler
 * Creator: rikard.herlitz, 2007-mar-21
 */
public interface ThrowableHandler {
	public void handle(Throwable t);
}
