package atechnique.models.interfaces;

public interface IStartServerModel {

}
